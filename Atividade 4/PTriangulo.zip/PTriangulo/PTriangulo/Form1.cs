﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {

        double LadoA, LadoB, LadoC;

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoB.Text, out LadoB)) ||
                (LadoB <= 0))
            {
                MessageBox.Show("Valor precisa ser numerico e maior que 0");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoC.Text, out LadoC)) ||
                (LadoC <= 0))
            {
                MessageBox.Show("Valor precisa ser numerico e maior que 0");
                txtLadoC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((LadoA < LadoB + LadoC) && LadoA > Math.Abs(LadoB - LadoC) &&
                (LadoA - LadoC < LadoB) && (LadoB < LadoA + LadoC) &&
                (LadoC > LadoA - LadoB) && (LadoC < LadoA + LadoB))
            {
                if ((LadoA == LadoB) && (LadoC == LadoB) && (LadoA == LadoC))
                {
                    MessageBox.Show("O seu triangulo é equilatero");
                }
                else if ((LadoA != LadoB) && (LadoC != LadoB) && (LadoA != LadoC))
                {
                    MessageBox.Show("O seu triangulo é Escaleno");
                }
                else 
                {
                    MessageBox.Show("O seu triangulo é Isósceles");
                }

            }
            else
                MessageBox.Show("Não é um triangulo");
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtLadoA.Text, out LadoA)) ||
                  (LadoA <= 0))
            {
                MessageBox.Show("Valor precisa ser numerico e maior que 0");
                txtLadoA.Focus();
            }
        }
    }
}
