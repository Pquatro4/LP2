﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int EspacoBranco=0;

            for (int i = 0; i < rchtxtFrase.TextLength; i++) 
            {
                if (rchtxtFrase.Text[i]==' ')
                {
                    EspacoBranco=EspacoBranco+1;
                   
                }
            }
            MessageBox.Show("A frase tem " + EspacoBranco + " Espaços Brancos");

        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int i = 0;
            int r = 0;
            while ( i < rchtxtFrase.TextLength)
            {
                if (rchtxtFrase.Text[i] == 'R' || rchtxtFrase.Text[i] == 'r')
                {
                    r = r + 1;
               
                }
                i++;
            }
         MessageBox.Show("A frase tem " + r + " letras R");
        }

        private void btnLetrasIguais_Click(object sender, EventArgs e)
        {
            int i = 1;
            int Pares = 0;
            do
            {
                if (rchtxtFrase.Text[i - 1] == rchtxtFrase.Text[i])
                {
                    Pares = Pares + 1;
                }
               i++;
           
            } while (i< rchtxtFrase.TextLength);

            MessageBox.Show("A frase tem " + Pares + " pares de letra");
        }
    }
}
