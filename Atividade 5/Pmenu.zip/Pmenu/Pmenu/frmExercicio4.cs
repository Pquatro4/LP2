﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenu
{
    public partial class frmExercicio4 : Form
    {
        int Contador, Tamanho;


        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNum_Click(object sender, EventArgs e)
        {
            Contador = 0;
            while (Contador< richTextFrase.TextLength)
            {
                if (char.IsNumber(richTextFrase.Text[Contador]))
                {
                    Contador++;

                }
                Co
                MessageBox.Show(Contador);
            }
        }
    }
}
