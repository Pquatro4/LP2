﻿namespace Pmenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextFrase = new System.Windows.Forms.RichTextBox();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnContLet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextFrase
            // 
            this.richTextFrase.Location = new System.Drawing.Point(200, 152);
            this.richTextFrase.Name = "richTextFrase";
            this.richTextFrase.Size = new System.Drawing.Size(293, 51);
            this.richTextFrase.TabIndex = 0;
            this.richTextFrase.Text = "";
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(200, 296);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(71, 42);
            this.btnContNum.TabIndex = 1;
            this.btnContNum.Text = "Contar numero";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.btnContNum_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(314, 296);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(75, 42);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "1° Espaço em branco";
            this.btnEspaco.UseVisualStyleBackColor = true;
            // 
            // btnContLet
            // 
            this.btnContLet.Location = new System.Drawing.Point(418, 296);
            this.btnContLet.Name = "btnContLet";
            this.btnContLet.Size = new System.Drawing.Size(75, 42);
            this.btnContLet.TabIndex = 3;
            this.btnContLet.Text = "Contar letras";
            this.btnContLet.UseVisualStyleBackColor = true;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContLet);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnContNum);
            this.Controls.Add(this.richTextFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextFrase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnContLet;
    }
}