﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482411024
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=BD;User ID=BD2411021;PASSWORD=A12345678a");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao abrir banco de dados" + ex.Message);
            }
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmContatos"];
            if (fc != null)

                fc.Close();

            frmContatos FRMC = new frmContatos();
            FRMC.MdiParent = this;
            FRMC.WindowState = FormWindowState.Maximized;
            FRMC.Show();
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre obj2 = new frmSobre();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();

            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
