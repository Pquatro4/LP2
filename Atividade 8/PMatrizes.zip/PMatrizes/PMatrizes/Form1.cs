﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} ° número", "Entrada de Dados");


                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }

            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "Andre", "Débora", "Fatima", "João", "Otavio", "Janete", "Pedro", "Marcelo" };
            lista.Remove("Otavio");
            string auxiliar = "";

            foreach (string s in lista)
            {
                auxiliar += s + "\n";
            }
            MessageBox.Show(auxiliar);
        }


        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string Media = "";
            string auxiliar = "";
            double[] MediaAluno = new double[20];
            for (var aluno = 0; aluno < 20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota", "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Nota Inválida");
                        nota--;
                    }
                    else if ((notas[aluno, nota] > 10) || (notas[aluno, nota] < 0))
                    {
                        MessageBox.Show("Deve ser entre 0 e 10");
                        nota--;
                    }
                    else
                    {
                        MediaAluno[aluno] += notas[aluno, nota];
                    }

                }

                MediaAluno[aluno] /= 3;
            }
            for (var aluno = 0; aluno < 20; aluno++)
            {
                Media += "Aluno" + (aluno + 1).ToString() + " " + MediaAluno[aluno].ToString("n2") + "\n";
            }
            MessageBox.Show(Media);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj = new frmExercicio4();
            obj.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj1 = new frmExercicio5();
            obj1.Show();
        }
    }
}
