﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] caracteres = new int[10];
            int espaçosbranco = 0;
            for (var i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox($"Digite o {i + 1} ° Nome", "Entrada de Dados");
                espaçosbranco = nomes[i].Count(c => c==' ');

                caracteres[i] = nomes[i].Length - espaçosbranco;
                ltbNomes.Items.Add("Aluno" + (i + 1).ToString() + " " + nomes[i].ToString() + " tem "+ caracteres[i] + " caracteres "+ "\n");
            }
        
        }
     }
 }

